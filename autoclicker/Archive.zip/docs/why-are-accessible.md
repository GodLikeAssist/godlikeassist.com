## Why are accessible services necessary?

TODO