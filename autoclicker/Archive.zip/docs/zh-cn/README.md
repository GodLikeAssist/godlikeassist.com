# GA 自动点击器

> A Godsent Auto-Clicker
